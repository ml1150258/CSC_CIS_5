/*
     Author: Dr. Mark E. Lehr
     Date:   June 23rd, 2025
     Purpose:  Template to start all Programming Assignments
*/

//System Libraries
#include <iostream>  //Input/Output
using namespace std;

//User Libraries

//Constants - Physics, Chemistry, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argv,char **argc){
    //Set the random number seed

    //Declare Variables

    //Initialize Variables

    //Process - Map the inputs to outputs

    //Display the results
    cout<<"Hello World"<<endl;

    //Clean up open files, allocated memory

    //Exit stage right
    return 0;
}