/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 5, 2022, 11:50 AM
 * Purpose:  Diamond Pattern
 */

//System Level Libraries
#include <iostream>  //Input-Output Library
using namespace std;

//User Defined Libraries

//Global Constants, not Global Variables
//These are recognized constants from the sciences
//Physics/Chemistry/Engineering and Conversions between
//systems of units!

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Initialize Random Seed once here!
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map the inputs/known to the outputs
    
    //Display the outputs
    cout<<"   *"<<endl;
    cout<<"  ***"<<endl;
    cout<<" *****"<<endl;
    cout<<"*******"<<endl;
    cout<<" *****"<<endl;
    cout<<"  ***"<<endl;
    cout<<"   *"<<endl;

    //Exit the program
    return 0;
}